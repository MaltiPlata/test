# maltiplata — v6 (restructured: homepage hub + topic pages)

## what changed in v6
**The original homepage is intact — unchanged, all 6,585px of it.** The reclaim wall,
the interactive decoder, the dictionary tiles, the money-map widget, free forms, find-a-pro,
the hero stickers and marquee are all exactly as they were.

What's ADDED (nothing removed):
- NEW `/topics/` section — subject pages, reachable from a new "topics" link in the nav
- NEW `/topics/_topics.js` — the topic registry (single source of truth)
- NEW `/topics/how-to-start-an-llc.html` — first fully-researched topic article (1,920 words)



## design consistency (v6.3) — verified across all 30 pages
Every page shares one system, all driven by `guides/_article.css`:

**Chrome (all 30):** sticky dark nav (62px) with the three-part `malti/plata` yellow-slash
logo, same 5 links, same yellow "join free" pill; dark footer with logo + disclaimer.

**Index pages (`/guides/`, `/topics/`):** identical 999px pill search, Archivo Black filter
buttons, and cards (2.5px border / 16px radius / 5px offset shadow / 20px padding /
ink `l-kind` badge / 17px Archivo Black title).

**Article pages (all 27) — every one has:** hero card, breadcrumb, kicker, meta row,
`a-tldr` summary, sidebar with TOC + money-map CTA, `a-nums` stat blocks where useful,
`a-table` for comparisons, `a-call` callouts with exactly one `a-call--accent` key takeaway,
collapsible `<details>` FAQ, `a-src` numbered citations, and the related-reads strip.

**Fixed in this pass:** the LLC topic page had invented its own classes (`a-resources`,
a plain `<ol>` FAQ) instead of using guide conventions — rewritten to match. Three guides
(dont-grubhub, health-insurance, the-pink-tax) were missing the accent callout the other
24 had — added. Unused CSS removed.

**Fixed in the screenshot-comparison pass (v6.4):** the homepage nav carried 8 links
(`why the name?`, `start here`, `the wall` extra) while every other page had 5 — now all
30 pages show the identical set: topics · guides · dictionary · find a pro · join free.
The homepage content containers were also 1200px vs 1100px everywhere else — aligned to
1100px. (The marquee and dictionary bands stay full-bleed at 1280px by design, with their
inner content constrained to 1100px.)

**Rule going forward:** never invent a new class. Copy an existing guide as the starting
point for any new article — it already carries every convention.


## content status (v7) — all 12 topics live
**Topic articles written (6 original, ~1,700–2,050 words each):**
| topic | sources |
|---|---|
| how-to-start-an-llc | SBA, IRS, FinCEN |
| how-to-build-credit | CFPB, FTC, FICO factor weights |
| emergency-fund | Federal Reserve SHED, BLS, FDIC |
| start-investing | IRS 2026 limits, Fidelity |
| how-to-file-taxes | IRS Free File, VITA, self-employment rules |
| prenup-101 | Uniform Law Commission (UPAA/UPMAA), CA Family Code |

**Topics mapped to existing guides (6).** These already had full guides, so their topic
cards link straight to them rather than duplicating the content — writing a second version
would have split traffic between two of our own pages competing for the same search terms:
- how-to-get-out-of-debt → `guides/how-to-get-out-of-debt.html`
- how-to-negotiate-salary → `guides/how-to-negotiate-your-salary.html`
- health-insurance → `guides/health-insurance-decoded.html`
- first-apartment → `guides/your-first-apartment.html`
- student-loans → `guides/student-loans-decoded.html`
- buying-a-car → `guides/buying-your-first-car.html`

The registry supports an optional `href` field for exactly this: set it and the card points
wherever you want, instead of assuming `/topics/<slug>.html`.

**Total: 35 pages · 294 internal links · 0 broken · 0 JS errors.**



## v8 — search, carousels, and everything as a page
**Sticky search header.** Scroll past the hero and a dark bar slides down with a search box,
logo, and join button. `assets/home-enhance.js` + `assets/home-enhance.css`.

**Autocomplete, everywhere.** Both the hero search and the sticky search now show live
results as you type — colour-coded by kind (word / topic / guide / page), keyboard
navigable (↑ ↓ Enter Esc), each going straight to a real page. Powered by
`assets/search-index.js` — **46 unique pages indexed**.

**Everything is a separate, searchable page now:**
- `dictionary/` — 10 term pages (roth ira, escrow, apr vs apy, vesting, prenup…) + a
  searchable, filterable index. Clicking a dictionary card on the homepage opens its page.
- `wall/` — the reclaim wall as its own page with all stories + a share CTA.

**Homepage sections shrunk to single-row carousels:**
| section | before | after |
|---|---|---|
| dictionary | 941px | 470px |
| reclaim wall | 1131px | 883px |

Both auto-cycle (pausable, arrow controls, pauses on hover, respects
`prefers-reduced-motion`) and end with a link to the full page.

**Art on the three start cards.** Inline SVG line-art backgrounds (no image files, no
licensing) so the block reads as three distinct cards rather than one repeated shape.

**To regenerate the search index** after adding content, rebuild it from the topic registry,
guides index, and dictionary — it's a plain JS file assigning `window.MALTI_SEARCH`.


## v9 — responding to the UX review
**Homepage cut 34%: 6,599px → 4,339px.** Four sections that now have dedicated pages were
removed from the homepage entirely (`decoder`, `toolkit`, `grownup`, `forms`), and the two
longest were compressed into single-strip previews with a link:
| section | before | after |
|---|---|---|
| matilda | 856px | 264px (strip → the-matilda-effect guide) |
| reclaim wall | 883px | 245px (strip → /wall/) |

**NEW `/start/` — the guided triage tool.** Users describe their situation in plain language
("my husband handled all the money and we split up") or tap one of 8 situation cards, and get
a short ordered path of 2–4 steps instead of a wall of content. Free-text matching runs on a
keyword map; unmatched queries get an honest fallback rather than a dead end. Deep-linkable
via `/start/?s=debt`. A lilac banner under the hero search points to it.

**NEW `/about/` — the trust page.** Who's behind it, the name story, the sourcing hierarchy
(government → primary research → commercial, in that order), a do/don't table drawing the
education-vs-advice line, how we'll make money and the three commitments about it, a
corrections policy, and an honest statement that the library has **not yet been reviewed by a
licensed CPA/CFP/attorney** — with a call for professionals to do it.

**Nav is now:** start here · topics · guides · dictionary · about · join free (all 49 pages).


## v10 — the structural-gap articles (Morning Brew style sourcing)
Three new topic articles, written with **inline hyperlinks on the words themselves** (the
Morning Brew pattern) so every claim links to its source where you read it — plus the usual
numbered source list at the bottom.

| article | words | inline source links |
|---|---|---|
| social security, the part nobody tells you | 2,095 | 23 |
| the caregiving career break, priced | 1,869 | 14 |
| the form that overrides your will | 1,668 | 13 |

**Why these three.** They're structural gaps that mainstream money media barely covers, and
they map to women's actual life paths rather than to investing-product marketing:
- **Divorced-spouse Social Security** — 10-year marriage rule, up to 50% of an ex's benefit
  (100% as a survivor), claimable without the ex knowing or losing a dollar.
- **The caregiving break** — CAP's 3–4x-salary-per-year-out finding and PensionBee's
  $346k five-year retirement gap, plus the protective moves (spousal IRA is the big one).
- **Beneficiary designations** — Kennedy v. Plan Administrator (2009) and Egelhoff (2001):
  the form beats the will, and beats the divorce decree.

**Search upgrade.** Index entries now carry a `kw` keyword field, so natural phrasing works:
"stay at home mom" → caregiving, "divorced" → social security, "will" → beneficiaries.

Site total: **52 pages · 578 internal links · 0 broken · 0 JS errors.**


## v11 — safety, retirement recovery, and finding help
Three more researched topic articles (Morning Brew-style inline source links):

| article | words | inline links |
|---|---|---|
| when money is the leash (financial abuse) | 1,967 | 21 |
| the 401(k) you left at an old job | 1,606 | 14 |
| how to vet a financial advisor | 1,704 | 19 |

**The financial-abuse page has safety features built in**, because the audience for it may be
monitored: a fixed **"quick exit ✕"** button that leaves the site immediately, a safety banner
above the article about device monitoring and clearing history, and the National Domestic
Violence Hotline (1-800-799-7233 / text START to 88788) surfaced at both the top and bottom.
Sources: NNEDV, PCADV, NYLAG, California DFPI, Insurance Information Institute.

**Search now handles natural language.** The scorer filters stopwords and matches on meaningful
tokens, so full sentences work:
- "my partner controls the money" → financial abuse
- "left my job retirement" → 401(k) rollover
- "how do i find an advisor" → vetting an advisor
- "stay at home mom" → caregiving career break

Site total: **55 pages · 608 internal links · 0 broken · 0 JS errors · 18 live topics.**


## v12 — divorce, disability, HSAs
Three more, same Morning Brew-style inline sourcing:

| article | words | inline links |
|---|---|---|
| the divorce money checklist | 1,748 | 16 |
| the insurance nobody talks about (disability) | 1,668 | 18 |
| the account with three tax breaks (HSA) | 1,623 | 15 |

Highlights: **QDROs** (a 401(k) needs a separate court order per plan; an IRA doesn't — and the
lump-sum QDRO distribution is the one route that dodges the 10% penalty under 59½).
**Disability** — 1 in 4 of today's 20-year-olds out of work a year+ before retirement, only ~33%
have employer LTD, and the "own occupation" vs "any occupation" distinction that decides claims.
**HSAs** — the only triple-tax-advantaged account, the receipt strategy with no time limit, and
the establishment-date rule that makes opening one early matter.

**New: `regen.py`.** One script rebuilds the topics index grid, the category filters, and the
search index from `topics/_topics.js`. Run it after adding any topic — no manual editing.

**Bug caught in testing:** a section id starting with a digit (`id="65"`) is an invalid CSS
selector and broke `querySelector`. Renamed to `after65`; all 21 topic pages audited for the
same pattern.

Site total: **58 pages · 638 internal links · 0 broken · 0 JS errors · 21 live topics.**


## v13 — the gap list is complete
The final five, closing out the content gap analysis:

| article | words | inline links |
|---|---|---|
| retirement when you work for yourself | 1,574 | 17 |
| the 20% down payment myth | 1,442 | 13 |
| rsus and the tax bill nobody warns you about | 1,665 | 19 |
| $124 trillion is about to change hands | 1,703 | 13 |
| do you need crypto? (honestly) | 1,523 | 10 |

**All 26 topics are now live.** The gap list identified after the "what am I missing" analysis
is fully written — 20 original topic articles plus 6 mapped to existing guides.

Highlights: **solo 401(k) vs SEP** can be worth $24,000/yr at ordinary incomes (the SEP's one
edge is the tax-filing-deadline funding window). **Down payments** — median first-time buyer is
~10%, not 20%. **RSUs** — the flat 22% supplemental withholding under-collects for anyone in the
24%+ brackets, and the $0-cost-basis 1099-B error is the most expensive filing mistake.
**Wealth transfer** — women expected to receive ~70% of $124T; the advice is do nothing for 90
days. **Crypto** — written as permission to skip rather than pressure to join, because women
hold less of it and have outperformed anyway.

Site total: **63 pages · 688 internal links · 0 broken · 0 JS errors · 26 live topics ·
62 pages in the search index.**


## v14 — palette, playful heroes, honest name story
**Hot pink retired.** `--pink` went from `#ff7ab6` (bubblegum) to `#9db8ff` (periwinkle) —
which also adds the palette's first cool hue, so it no longer reads as default-women's-brand
pink. Changed in `guides/_article.css` AND inside the homepage bundle (it stores its own copy,
uppercase `#FF7AB6`). Verified: 0 hot-pink elements sitewide.

**Playful details on the coloured headline boxes:**
- dot-halftone texture in the top-right corner of every article hero
- a hand-drawn SVG underline swoop beneath each h1
- the category kicker is now a tilted sticker with a drop shadow
- confetti seeds beside the dek; index cards get a corner seed too

**The name story is plainer.** The old strip led with a slogan ("they wrote her out / we wrote
her back in"). It now leads with "matilda + plata. the honest version," names Matilda Joslyn
Gage and 1876, says plainly that *plata* is just the word our founder grew up with in Chile,
and admits we almost picked something easier to spell. The about page matches.

**Bugs fixed:** `down-payment-myth` referenced an undefined `--butter` variable; the new kicker
styling initially overlapped the h1 and hid its own text (dark pill, cream text, overridden
background). Both caught in testing.

**Inline-link audit.** 13 articles had 5–19 inline source links; 18 had zero. Added links to
the six early topic pages. **The 26 original guides still need a manual pass** — see below.


## v15 — inline source links (Morning Brew style) across the library
Started at **18 articles with zero inline links**. Now **5**, and each of those five has a
reason:

| article | why it has none |
|---|---|
| the-stuff-nobody-taught-you | orientation page — routes to other guides, makes no sourced claims |
| your-first-apartment | rules of thumb (30% rent), no external sources cited yet |
| sudden-money-what-to-do | behavioural advice, no statistics cited |
| mortgage-points-worth-it | pure arithmetic (break-even math), self-contained |
| dont-grubhub-invest-the-difference | illustrative compounding math, self-contained |

Those four non-orientation ones need **new research** to earn citations — I didn't invent
sources to fill the gap.

**Two factual corrections came out of this pass:**
1. `women-money-101` said women earn "roughly 85 cents." That's Pew's measure (hourly, all
   workers). Census's full-time year-round measure is **81 cents**, and it has widened two
   years running — the first back-to-back widening since the 1960s. The guide now states both
   measures, each linked to its own source, consistent with how the other guides cite it.
2. An invented Census URL got caught before shipping and replaced with verified USAFacts and
   NWLC links.

**Method note:** every URL added was either already cited on the page or verified by search
first. Mis-attributed links are worse than no links.


## v16 — header rewrite + "start with a topic" was actually broken
**The section wasn't styled — it was three real bugs:**
1. The injector emitted `soon-name` / `soon-go`, class names that **don't exist** in the
   stylesheet, so titles rendered as plain 16px body text instead of Archivo Black.
2. Live cards used `soon-card` instead of `soon-card soon-card--live`, so every card rendered
   as a **default underlined blue link**.
3. `COLORS` had no entry for `retirement` or `safety`, and the homepage's own `:root` was
   missing `--leaf` and `--coral` — so half the cards had **no background at all**.

Fixed all three, added a corner dot texture matching the article heroes, and diversified the
category palette (work → coral, life → yellow) so adjacent cards no longer alternate between
two colours. `regen.py` updated to match, so the topics index stays consistent.

**New header.** Was: *"money 101, on your terms."* Now:

> **the money talk `nobody` gave you.**
> not at the dinner table, not at school, not anywhere. so we wrote it down — every money and
> legal word, in plain language, at your own pace.

It states the problem instead of the category, and it's the same thesis the rest of the site
runs on. Alternates considered: "you weren't bad at money. you were left out of the room." /
"the stuff they skipped." / "your money. your name. your call."


## v17 — "the stuff they skipped" + build-your-own-thing + herstory
**New header.** *"the stuff `they` skipped."* — sub: "money, legal, and how to actually build
something — in plain language. the class nobody gave you, closing the gap any way we can."

**NEW `/herstory/` — then. now. next.** The financial timeline, because every gap this site
closes has a date on it and the dates are recent: **1974** ECOA (a credit card in her own name),
**1988** Women's Business Ownership Act (a business loan without a male co-signer in every
state), **2013** CARD Act amendment (household income for stay-at-home spouses), and next the
$124T transfer. Includes the honest caveat that ECOA formalized the right to *sue* over
discrimination rather than inventing access from nothing. Ends on "you're not behind. you're early."

**Minimal on the homepage, as asked:** one quiet line above "start here" — a pill, a year, one
fact, rotating every 5 seconds, linking to the full page. No block, no grid, no takeover.
Respects `prefers-reduced-motion`.

**NEW category: `build` — build your own thing.** The badass pillar:
- `start-an-etsy-shop` — **written**, 1,818 words, 21 inline source links
- `build-with-ai` (vibe-coding without a CS degree) — registered, coming soon
- `creator-income` (tiktok & instagram) — registered, coming soon
- `sell-on-amazon` — registered, coming soon

The Etsy piece leads with the numbers the tutorials skip: ~10% fees before ads, **22–25% after**
offsite ads become mandatory at $10k/yr, the **median seller earns under $500/year**, and digital
products carry 70–90% margins versus 20–40% handmade.

Site total: **65 pages · 0 broken links · 0 JS errors · 27 live topics.**


## v18 — trademark + vibe coding, and the build pillar filled out
Two written:

| article | words | inline links |
|---|---|---|
| how to trademark your name | 1,885 | 21 |
| build it yourself with ai | 1,841 | 15 |

**A correction worth knowing:** the USPTO **eliminated the TEAS Plus ($250) / TEAS Standard
($350) tiers on January 18, 2025** and replaced them with a single **$350 base fee per class
plus surcharges**. A large share of 2026-dated articles still quote the old two-tier system.
Ours states the current structure and flags that the stale number is circulating.

**The AI piece leads with the thing beginner guides skip:** AI-generated code carries roughly
**1.7x more major issues** than human-written code, and non-engineers can't spot them. So the
rule is match the stakes to the tool — landing pages and internal tools yes, anything holding
payment or health data gets a human review first. It also separates browser tools (Lovable,
Bolt, Replit, v0) from developer tools (Cursor, Claude Code), which is the single most common
reason beginners bounce.

**Five more topics registered** (my suggestions, not yet written):
`price-your-work` · `get-paid-freelance` · `women-owned-certification` (WBENC/WOSB) ·
`business-banking-books` · `read-a-contract`

Site total: **67 pages · 0 broken links · 0 JS errors · 30 live topics · 41 registered.**


## v18 — the "build your own thing" pillar
Three written, four more registered. This is the badass pillar: not just managing money, but
making it.

| article | words | inline links |
|---|---|---|
| start an etsy shop (with the real numbers) | 1,818 | 21 |
| how to trademark your name | 1,752 | 17 |
| build it yourself with ai | 1,690 | 14 |

**Two corrections that came out of the research:**
1. **Trademark fees changed.** Most articles still quote TEAS Plus ($250) / TEAS Standard ($350).
   Those tiers were **eliminated January 18, 2025** and replaced with a single **$350 per class**
   base fee plus surcharges, filed through the new Trademark Center. Verified against USPTO.
2. **The AI security risk nobody tells beginners.** An analysis of 470 pull requests found AI
   co-authored code had **1.7x more major issues** — SQL injection, hardcoded API keys, XSS —
   and non-engineers can't spot them. The article draws a hard line: build freely with no real
   user data or money moving; get human review before payments, logins, or personal data.

**Registered, coming soon (my additions to the pillar):**
- `woman-owned-certification` — WOSB / WBENC, what it unlocks and whether it's worth it
- `get-paid-freelance` — contracts, deposits, and chasing unpaid invoices
- `price-your-work` — hourly vs project vs value, and raising rates on existing clients
- `creator-income` — tiktok & instagram monetisation
- `sell-on-amazon` — FBA fees and whether it's still worth entering

Site total: **67 pages · 0 broken links · 0 JS errors · 31 live topics · 65 pages searchable.**

## v19 — the flagship, plus two registry bugs fixed

**`guides/why-you-were-never-taught-this.html`** — 1,900 words, 21 inline source links.
The origin-story piece the whole site rests on: women couldn't get a credit card in their own
name until **1974**, or a business loan without a male relative co-signing until **1988**.
Sources are primary where possible — National Archives, Ford Presidential Library, Congress.gov
(H.R. 5050), Federal Reserve FEDS Notes, CEE Survey of the States 2026, TIAA PFI 2026, GFLEC.

Registered on the guides index (first card), the homepage guide grid, and the search index.
Cross-linked from `/herstory/` and from the matilda-effect guide's read-next.

### two bugs found in v18

1. **The registry had the build pillar in it three times.** `topics/_topics.js` held 45 entries
   for 38 slugs — `trademark-your-name`, `start-an-etsy-shop`, `build-with-ai`, `price-your-work`,
   `get-paid-freelance`, and `sell-on-amazon` were each duplicated, plus near-duplicate slugs
   (`woman-owned` vs `women-owned`, `creator-income` vs `get-paid-as-a-creator`). Since `regen.py`
   only de-dupes the *search* index, `/topics/` was rendering the same card two or three times.
   Now 36 unique entries, one clean build block.
2. **`regen.py` couldn't be re-run.** It loaded `/tmp/dict.json` and `/tmp/guides.json`, which were
   session scratch files that no longer existed — so running it would crash. It now scrapes the
   dictionary and guides straight from their own index pages, including the `data-text` keywords,
   which also means guide and dictionary entries now carry search keywords they previously lost.

Site total: **68 pages · 1,359 internal links · 0 broken · 0 JS errors · 29 live topics · 66 pages searchable.**

## the structure
```
index.html                  → lean hub: 6 top topics + 3 top guides + matilda band + money map
topics/
  index.html                → all topics, searchable + filterable by category
  _topics.js                → THE REGISTRY (add topics here)
  how-to-start-an-llc.html  → live, fully researched
guides/
  index.html                → the 26-guide library (unchanged)
  _article.css              → shared styles (now also covers topic pages)
  _guard.js                 → link safety net
  *.html                    → all 26 guides
downloads/                  → the money map PDF
```

## how to add a topic (2 steps)
1. **Register it** in `topics/_topics.js`:
   ```js
   { slug:"how-to-build-credit", emoji:"💳", title:"how to build credit", cat:"credit",
     featured:true, ready:false,
     blurb:"one sentence that earns the click." }
   ```
   With `ready:false` it shows as "coming soon" and is NOT clickable — so a registered
   topic can never produce a 404 before its page exists.
2. **Write the page**, then flip `ready:true`. Copy `topics/how-to-start-an-llc.html` as
   your template — it has the full structure: TL;DR → sections → `.a-call` callouts →
   `.a-steps-list` numbered steps → `.a-resources` link list → FAQ → sidebar TOC.

`featured:true` surfaces it on the homepage (first 6 shown).

## the article recipe (what makes these work)
Every topic article follows the same shape the 26 guides use:
1. **TL;DR** — the whole answer in 4-5 bullets, with real numbers
2. **What it actually is** — plain language, no assumed knowledge
3. **What it really costs** — actual figures, not "it varies"
4. **The steps, in order** — numbered, doable
5. **Callouts** for the traps people fall into
6. **The resources worth your time** — free/official sources first (.gov before .com)
7. **The bottom line** + one tiny next step
8. **FAQ** — the questions people actually search

## deploy (Netlify, ~2 min)
1. UNZIP to a NEW, empty folder.
2. app.netlify.com → "Add new site" → "Deploy manually"
3. Drag the WHOLE unzipped folder onto the page.

## cache gotcha
Update not showing? Hard-refresh (Cmd+Shift+R) or use an incognito window. Always unzip
to a fresh folder so old files don't linger.

## still to write (registered, marked "coming soon")
how-to-build-credit · how-to-file-taxes · how-to-get-out-of-debt (topic version) ·
start-investing · emergency-fund · how-to-negotiate-salary · prenup-101 ·
health-insurance · first-apartment · student-loans · buying-a-car

## when you get a real domain
Search-replace `maltiplata.netlify.app` across the HTML (canonical + og: tags).
