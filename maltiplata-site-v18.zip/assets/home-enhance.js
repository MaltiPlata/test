/* ============================================================
   maltiplata — homepage enhancements
   sticky search · autocomplete · carousels · card art
   Runs after the React app renders; retries until DOM is ready.
   ============================================================ */
(function () {
  'use strict';

  /* ---------------- 1. STICKY SEARCH HEADER ---------------- */
  function stickySearch() {
    if (document.getElementById('mp-stickybar')) return true;
    var hero = document.querySelector('.hero-search');
    var nav = document.querySelector('nav.nav');
    if (!hero || !nav) return false;

    var bar = document.createElement('div');
    bar.id = 'mp-stickybar';
    bar.innerHTML =
      '<div class="mp-sticky-in">' +
      '<a class="mp-sticky-logo" href="./index.html">malti<span>/</span>plata</a>' +
      '<div class="mp-sb-wrap">' +
      '<input id="mp-sb-input" type="search" autocomplete="off" ' +
      'placeholder="search everything — roth ira, debt, llc…" aria-label="search maltiplata" />' +
      '<div class="mp-ac" id="mp-sb-ac" role="listbox" hidden></div>' +
      '</div>' +
      '<a class="mp-sticky-cta" href="#join">join free</a>' +
      '</div>';
    document.body.appendChild(bar);

    var shown = false;
    function onScroll() {
      var r = hero.getBoundingClientRect();
      var should = r.bottom < 60;
      if (should !== shown) {
        shown = should;
        bar.classList.toggle('is-on', shown);
      }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    wireAutocomplete(document.getElementById('mp-sb-input'), document.getElementById('mp-sb-ac'));
    return true;
  }

  /* ---------------- 2. AUTOCOMPLETE ---------------- */
  function score(item, q) {
    var t = item.t.toLowerCase(), d = (item.d || '').toLowerCase(),
        kw = (item.kw || '').toLowerCase(), c = (item.c || '').toLowerCase();
    var hay = t + ' ' + kw + ' ' + c + ' ' + d;
    if (t === q) return 100;
    if (t.indexOf(q) === 0) return 80;
    if (t.indexOf(q) > -1) return 60;
    if (kw.indexOf(q) > -1) return 50;
    if (c.indexOf(q) > -1) return 40;
    if (d.indexOf(q) > -1) return 25;
    // multi-word: ignore stopwords, score on meaningful tokens that hit
    var STOP = {'my':1,'i':1,'the':1,'a':1,'an':1,'do':1,'does':1,'how':1,'what':1,'is':1,
                'are':1,'to':1,'of':1,'for':1,'and':1,'in':1,'on':1,'me':1,'with':1,'about':1,
                'can':1,'should':1,'need':1,'want':1,'have':1,'has':1,'get':1,'find':1,'it':1,
                'this':1,'that':1,'from':1,'at':1,'be':1,'if':1,'when':1,'help':1};
    var toks = q.split(/\s+/).filter(function(x){ return x && !STOP[x] && x.length > 2; });
    if (toks.length) {
      var hits = 0, s = 0;
      for (var i = 0; i < toks.length; i++) {
        if (hay.indexOf(toks[i]) > -1) { hits++; s += (t.indexOf(toks[i]) > -1) ? 9 : 5; }
      }
      if (hits && hits >= Math.ceil(toks.length / 2)) return 15 + s;
    }
    return 0;
  }

  function search(q) {
    var data = window.MALTI_SEARCH || [];
    q = (q || '').trim().toLowerCase();
    if (!q) return [];
    return data
      .map(function (x) { return { x: x, s: score(x, q) }; })
      .filter(function (r) { return r.s > 0; })
      .sort(function (a, b) { return b.s - a.s; })
      .slice(0, 7)
      .map(function (r) { return r.x; });
  }

  var KIND = { word: 'word', topic: 'topic', guide: 'guide', page: 'page' };

  function wireAutocomplete(input, box) {
    if (!input || !box || input.dataset.mpWired) return;
    input.dataset.mpWired = '1';
    var active = -1, results = [];

    function render() {
      if (!results.length) {
        box.hidden = true;
        box.innerHTML = '';
        return;
      }
      box.innerHTML = results.map(function (r, i) {
        return '<a class="mp-ac-row' + (i === active ? ' is-active' : '') + '" href="./' + r.u + '" role="option">' +
          '<span class="mp-ac-kind mp-ac-kind--' + r.k + '">' + (KIND[r.k] || r.k) + '</span>' +
          '<span class="mp-ac-txt"><b>' + esc(r.t) + '</b><i>' + esc(r.d || '') + '</i></span>' +
          '<span class="mp-ac-go">→</span></a>';
      }).join('') +
        '<a class="mp-ac-all" href="./topics/index.html">see all topics &amp; guides →</a>';
      box.hidden = false;
    }

    function esc(s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

    input.addEventListener('input', function () {
      results = search(input.value); active = -1; render();
    });
    input.addEventListener('keydown', function (e) {
      if (!results.length) return;
      if (e.key === 'ArrowDown') { e.preventDefault(); active = Math.min(active + 1, results.length - 1); render(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); active = Math.max(active - 1, -1); render(); }
      else if (e.key === 'Enter') {
        e.preventDefault();
        var pick = results[active > -1 ? active : 0];
        if (pick) location.href = './' + pick.u;
      } else if (e.key === 'Escape') { box.hidden = true; }
    });
    input.addEventListener('blur', function () { setTimeout(function () { box.hidden = true; }, 160); });
    input.addEventListener('focus', function () { if (results.length) box.hidden = false; });
  }

  /* ---------------- 3. HERO SEARCH → real autocomplete ---------------- */
  function heroSearch() {
    var wrap = document.querySelector('.hero-search');
    if (!wrap) return false;
    var input = wrap.querySelector('input');
    if (!input) return false;
    if (!document.getElementById('mp-hero-ac')) {
      var box = document.createElement('div');
      box.className = 'mp-ac mp-ac--hero';
      box.id = 'mp-hero-ac';
      box.hidden = true;
      wrap.style.position = 'relative';
      wrap.appendChild(box);
    }
    wireAutocomplete(input, document.getElementById('mp-hero-ac'));
    return true;
  }

  /* ---------------- 4. CAROUSEL (dictionary + wall) ---------------- */
  function makeCarousel(sectionId, cardSel, opts) {
    var sec = document.getElementById(sectionId);
    if (!sec || sec.dataset.mpCarousel) return false;
    var cards = sec.querySelectorAll(cardSel);
    if (!cards.length) return false;
    sec.dataset.mpCarousel = '1';

    var first = cards[0];
    var grid = first.parentNode;
    grid.classList.add('mp-rail');

    var wrap = document.createElement('div');
    wrap.className = 'mp-rail-wrap';
    grid.parentNode.insertBefore(wrap, grid);
    wrap.appendChild(grid);

    var ctrls = document.createElement('div');
    ctrls.className = 'mp-rail-ctrls';
    ctrls.innerHTML =
      '<button class="mp-rail-btn" data-dir="-1" aria-label="previous">&#8592;</button>' +
      '<button class="mp-rail-btn" data-rail-pause aria-label="pause">&#10073;&#10073;</button>' +
      '<button class="mp-rail-btn" data-dir="1" aria-label="next">&#8594;</button>' +
      (opts.allHref ? '<a class="mp-rail-all" href="' + opts.allHref + '">' + opts.allLabel + '</a>' : '');
    wrap.appendChild(ctrls);

    var timer = null, paused = false;
    function step(dir) {
      var w = grid.querySelector(cardSel);
      var d = (w ? w.getBoundingClientRect().width + 16 : 320) * dir;
      var atEnd = grid.scrollLeft + grid.clientWidth >= grid.scrollWidth - 8;
      if (dir > 0 && atEnd) grid.scrollTo({ left: 0, behavior: 'smooth' });
      else grid.scrollBy({ left: d, behavior: 'smooth' });
    }
    ctrls.querySelectorAll('[data-dir]').forEach(function (b) {
      b.addEventListener('click', function () { step(+b.dataset.dir); restart(); });
    });
    var pauseBtn = ctrls.querySelector('[data-rail-pause]');
    pauseBtn.addEventListener('click', function () {
      paused = !paused;
      pauseBtn.innerHTML = paused ? '&#9654;' : '&#10073;&#10073;';
      pauseBtn.setAttribute('aria-label', paused ? 'play' : 'pause');
      if (paused) clearInterval(timer); else restart();
    });
    function restart() {
      clearInterval(timer);
      if (paused) return;
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      timer = setInterval(function () { step(1); }, opts.delay || 4200);
    }
    grid.addEventListener('mouseenter', function () { clearInterval(timer); });
    grid.addEventListener('mouseleave', restart);
    restart();
    return true;
  }

  /* ---------------- 5. ART ON THE THREE START CARDS ---------------- */
  var ART = [
    "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cg fill='none' stroke='%230f0f0e' stroke-width='2.5' opacity='.16'%3E%3Ccircle cx='170' cy='55' r='42'/%3E%3Ccircle cx='170' cy='55' r='26'/%3E%3Cpath d='M120 190 L160 140 L185 165 L215 120'/%3E%3C/g%3E%3C/svg%3E\")",
    "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cg fill='none' stroke='%230f0f0e' stroke-width='2.5' opacity='.16'%3E%3Crect x='128' y='30' width='70' height='48' rx='8'/%3E%3Crect x='142' y='52' width='70' height='48' rx='8'/%3E%3Cpath d='M120 185 h100 M120 165 h70'/%3E%3C/g%3E%3C/svg%3E\")",
    "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cg fill='none' stroke='%230f0f0e' stroke-width='2.5' opacity='.16'%3E%3Cpath d='M150 100 q30-45 60 0 q-30 45-60 0z'/%3E%3Cpath d='M180 100 v75'/%3E%3Cpath d='M135 175 h90'/%3E%3C/g%3E%3C/svg%3E\")"
  ];
  function cardArt() {
    var cards = document.querySelectorAll('#start-here .start-step');
    if (!cards.length) return false;
    if (cards[0].dataset.mpArt) return true;
    cards.forEach(function (c, i) {
      c.dataset.mpArt = '1';
      c.style.backgroundImage = ART[i % ART.length];
      c.style.backgroundRepeat = 'no-repeat';
      c.style.backgroundPosition = 'right -14px bottom -14px';
      c.style.backgroundSize = '190px 190px';
    });
    return true;
  }


  /* ---------------- 6. DICTIONARY CARDS → their own pages ---------------- */
  var SLUGS = {};
  function linkDictCards() {
    var cards = document.querySelectorAll('#dictionary .dictionary-card');
    if (!cards.length) return false;
    if (cards[0].dataset.mpLinked) return true;
    (window.MALTI_SEARCH || []).forEach(function (r) {
      if (r.k === 'word') SLUGS[r.t.toLowerCase()] = r.u;
    });
    cards.forEach(function (c) {
      c.dataset.mpLinked = '1';
      var nameEl = c.querySelector('.dictionary-card-name');
      var name = (nameEl ? nameEl.textContent : '').trim().toLowerCase();
      var url = SLUGS[name];
      if (!url) return;
      c.style.cursor = 'pointer';
      var cta = c.querySelector('.dictionary-card-cta');
      if (cta) cta.textContent = 'read the full word →';
      c.addEventListener('click', function (e) {
        e.preventDefault(); e.stopPropagation();
        location.href = './' + url;
      }, true);
    });
    return true;
  }


  /* -------- 7. SHORTEN: hide redundant sections, compact the long ones -------- */
  /* every one of these now has its own dedicated page, so the homepage
     doesn't need to carry the whole thing inline. */
  function hideSections() {
    var kill = ['decoder', 'toolkit', 'grownup', 'forms'];
    var did = false;
    kill.forEach(function (id) {
      var e = document.getElementById(id);
      if (e && e.style.display !== 'none') { e.style.display = 'none'; did = true; }
    });
    return did;
  }

  function compact(sectionId, cfg) {
    var sec = document.getElementById(sectionId);
    if (!sec || sec.dataset.mpCompact) return false;
    sec.dataset.mpCompact = '1';
    sec.innerHTML =
      '<div class="mp-strip" style="background:' + cfg.bg + '">' +
      '<div class="mp-strip-txt">' +
      '<p class="mp-strip-k">' + cfg.kicker + '</p>' +
      '<h2 class="mp-strip-h">' + cfg.head + '</h2>' +
      '<p class="mp-strip-p">' + cfg.body + '</p>' +
      '</div>' +
      '<a class="mp-strip-cta" href="' + cfg.href + '">' + cfg.cta + '</a>' +
      '</div>';
    return true;
  }

  /* -------- 8. "WHERE DO I START?" ENTRY BANNER -------- */
  function startBanner() {
    if (document.getElementById('mp-startbar')) return true;
    var anchor = document.querySelector('.hero-search');
    if (!anchor) return false;
    var host = anchor.parentNode;
    var bar = document.createElement('a');
    bar.id = 'mp-startbar';
    bar.href = './start/index.html';
    bar.innerHTML =
      '<span class="mp-sb-emoji">\uD83E\uDDED</span>' +
      '<span class="mp-sb-copy"><b>not sure where to start?</b>' +
      '<i>tell us what\u2019s going on \u2014 we\u2019ll point you at the 2\u20133 things that help</i></span>' +
      '<span class="mp-sb-go">\u2192</span>';
    host.insertBefore(bar, anchor.nextSibling);
    return true;
  }


  /* -------- 9. THEN/NOW: one quiet line, rotating -------- */
  var HERSTORY = [
    ['1974', 'the year a woman could first get a credit card without a man\u2019s signature.'],
    ['1988', 'the year she could get a business loan without one.'],
    ['1975', 'the year the first women-run bank opened in the US.'],
    ['1993', 'the year unpaid family leave became federal law. still unpaid.'],
    ['2030', 'the year women are projected to control two-thirds of US private wealth.']
  ];
  function herstoryLine() {
    if (document.getElementById('mp-hxline')) return true;
    var anchor = document.getElementById('start-here') || document.getElementById('top-topics');
    if (!anchor) return false;
    var a = document.createElement('a');
    a.id = 'mp-hxline';
    a.href = './herstory/index.html';
    a.innerHTML = '<span class="hx-yr"></span><span class="hx-txt"></span><span class="hx-go">then / now / next &rarr;</span>';
    anchor.parentNode.insertBefore(a, anchor);
    var i = 0;
    function paint() {
      var h = HERSTORY[i % HERSTORY.length];
      a.querySelector('.hx-yr').textContent = h[0];
      a.querySelector('.hx-txt').textContent = h[1];
      i++;
    }
    paint();
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setInterval(function () {
        a.classList.add('is-fading');
        setTimeout(function () { paint(); a.classList.remove('is-fading'); }, 320);
      }, 6000);
    }
    return true;
  }


  /* -------- 9. HERSTORY: one quiet rotating line, links to the full page -------- */
  var HERSTORY = [
    ['1974', 'a credit card in her own name — without a man\u2019s signature.'],
    ['1988', 'a business loan in every state, without a male co-signer.'],
    ['1963', 'equal pay became law. the gap is still open sixty years on.'],
    ['2013', 'stay-at-home spouses could finally count household income.'],
    ['next', 'women are expected to receive ~70% of a $124 trillion transfer.']
  ];
  function herstoryLine() {
    if (document.getElementById('mp-herstory')) return true;
    var anchor = document.getElementById('start-here');
    if (!anchor) return false;
    var a = document.createElement('a');
    a.id = 'mp-herstory';
    a.href = './herstory/index.html';
    a.innerHTML = '<span class="mp-hs-k">herstory</span>' +
                  '<span class="mp-hs-y"></span>' +
                  '<span class="mp-hs-t"></span>' +
                  '<span class="mp-hs-go">then / now / next &rarr;</span>';
    anchor.parentNode.insertBefore(a, anchor);
    var i = 0;
    var yEl = a.querySelector('.mp-hs-y'), tEl = a.querySelector('.mp-hs-t');
    function show() {
      var row = HERSTORY[i % HERSTORY.length];
      yEl.textContent = row[0];
      tEl.textContent = row[1];
      i++;
    }
    show();
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setInterval(function () { a.style.opacity = '0';
        setTimeout(function () { show(); a.style.opacity = '1'; }, 260); }, 5200);
    }
    return true;
  }

  /* ---------------- run + retry ---------------- */
  var done = {};
  function tick() {
    if (!done.sticky) done.sticky = stickySearch();
    if (!done.hero) done.hero = heroSearch();
    if (!done.art) done.art = cardArt();
    if (!done.dict) done.dict = makeCarousel('dictionary', '.dictionary-card',
      { delay: 4200, allHref: './dictionary/index.html', allLabel: 'all words →' });
    if (!done.wall) done.wall = makeCarousel('reclaim', '.reclaim-card',
      { delay: 5200, allHref: './wall/index.html', allLabel: 'the whole wall →' });
    if (!done.dictlink) done.dictlink = linkDictCards();
    if (!done.startbar) done.startbar = startBanner();
    if (!done.herstory) done.herstory = herstoryLine();
    if (!done.hx) done.hx = herstoryLine();
    if (!done.hide) done.hide = hideSections();
    if (!done.cMat) done.cMat = compact('matilda', {
      bg:'var(--pink)', kicker:'why the name?',
      head:'matilda + plata. <span style="background:var(--yellow);padding:0 6px;border-radius:6px">the honest version.</span>',
      body:'the <b>Matilda effect</b> is a real, documented thing \u2014 a pattern historians named after Matilda Joslyn Gage, who wrote in 1876 about women\u2019s ideas ending up under men\u2019s names. <b>plata</b> is just what money is called in Chile, where our founder is from. say the whole thing out loud and you\u2019ll hear the third part: <em>multiplica la plata</em>. it\u2019s a lot of meaning for one word, and honestly we almost picked something easier to spell.',
      cta:'read about the matilda effect \u2192', href:'./guides/the-matilda-effect.html' });
    if (!done.cWall) done.cWall = compact('reclaim', {
      bg:'var(--yellow)', kicker:'the reclaim wall',
      head:'we\u2019re done being quiet about money.',
      body:'anonymous stories from women who were kept out of the money conversation \u2014 and exactly what they took back. yours can be one of them.',
      cta:'read the wall \u2192', href:'./wall/index.html' });
  }
  function start() { tick(); [250, 700, 1400, 2500].forEach(function (t) { setTimeout(tick, t); }); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
